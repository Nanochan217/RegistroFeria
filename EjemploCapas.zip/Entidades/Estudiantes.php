<?php

class Estudiantes
{
    private $id;
    private $nombre;
    private $correo;
    private $idCurso;
    
    function getId() {
        return $this->id;
    }

    function getNombre() {
        return $this->nombre;
    }

    function getCorreo() {
        return $this->correo;
    }

    function getIdCurso() {
        return $this->idCurso;
    }

    function setId($id): void {
        $this->id = $id;
    }

    function setNombre($nombre): void {
        $this->nombre = $nombre;
    }

    function setCorreo($correo): void {
        $this->correo = $correo;
    }

    function setIdCurso($idCurso): void {
        $this->idCurso = $idCurso;
    }


            
}