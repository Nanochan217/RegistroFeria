<?php
    include '../BL/Estudiante/EstudianteBuscarTodos.php';
?>
<!doctype html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <title>COVAO</title>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col text-center p-3">
                    <h3>Estudiantes</h3>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th scope="col">Nombre</th>
                            <th scope="col">Correo</th>
                            <th scope="col">Curso</th>
                            <th scope="col">Actualizar</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php
                            if($todos!=null)
                            {
                                foreach ($todos as $t)
                                {
                                    ?>
                                        <tr>
                                            <td><?php echo $t->getNombre() ?></td>
                                            <td><?php echo $t->getCorreo() ?></td>
                                            <td>
                                                <?php
                                                if($todosCursos!=null)
                                                {
                                                    foreach ($todosCursos as $c)
                                                    {
                                                        if($t->getIdCurso()==$c->getId())
                                                        {
                                                            echo $c->getnombre();
                                                            break;
                                                        }
                                                    }
                                                }
                                                ?>
                                            </td>
                                            <td><a href="./ActualizarEstudiante.php?id=<?php echo $t->getId() ?>" ><i class="fa-solid fa-marker"></i></a></td>
                                        </tr>
                                    <?php
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col text-center">
                </div>
                <div class="col text-center">
                    <a href="NuevoEstudiante.php" class="btn btn-primary">Nuevo Estudiante</a>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col text-center p-3">
                    <h3>Cursos</h3>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">Actualizar</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php
                            if($todosCursos!=null)
                            {
                                foreach ($todosCursos as $c)
                                {
                                    ?>
                                    <tr>
                                        <td><?php echo $c->getId() ?></td>
                                        <td><?php echo $c->getNombre() ?></td>
                                        <td><a href="./ActualizarCurso.php?id=<?php echo $c->getId() ?>" ><i class="fa-solid fa-marker"></i></a></td>
                                    </tr>
                                    <?php
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col text-center">
                </div>
                <div class="col text-center">
                    <a href="./NuevoCurso.php" class="btn btn-primary">Nuevo Curso</a>
                </div>
            </div>
        </div>


        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    </body>
</html>

