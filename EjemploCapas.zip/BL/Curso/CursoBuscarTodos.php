<?php
    session_start();
    if(!isset($_SESSION["idUsuario"]))
        header("Location: ./");

    include '../DAL/Conexion.php';
    include "../Entidades/Cursos.php";
    include "../DAL/CursoDAL.php";
    

    $cursoDAL=new CursoDAL();

    $todos=$cursoDAL->BuscarTodos();
    

