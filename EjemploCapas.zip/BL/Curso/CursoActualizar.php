<?php
    session_start();
    if(isset($_SESSION["alerta"]))
        $alerta=$_SESSION["alerta"];




    include '../DAL/Conexion.php';
    include "../Entidades/Cursos.php";
    include "../DAL/CursoDAL.php";
    
    $curso = new Cursos();
    $cursosDAL = new CursoDAL();

    if(isset($_REQUEST['id']))
    {
        $id=$_REQUEST['id'];
        $curso=$cursosDAL->BuscarId($id);
        if($curso==null)
            header("Location: ./");
    }
    else
        header("Location: ./");






    