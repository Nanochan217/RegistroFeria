<?php

    include '../../DAL/Conexion.php';
    include "../../Entidades/Cursos.php";
    include "../../DAL/CursoDAL.php";

    $curso=new Cursos();
    $cursosDAL=new CursoDAL();


    $curso->setNombre($_POST['nombre']);

    if($cursosDAL->Nuevo($curso))
        header("Location: ../../GUI/");
    else
        header("Location: ../../GUI/NuevoCurso.php");