<?php
    session_start();
    include "../../DAL/Conexion.php";
    include "../../Entidades/Cursos.php";
    include "../../DAL/CursoDAL.php";
    
    $curso=new Cursos();
    $cursoDAL=new CursoDAL();

    $curso->setId($_POST['id']);
    $curso->setNombre($_POST['nombre']);
    //var_dump($curso);

    if(!$cursoDAL->ActualizarNombre($curso))
        header("Location: ../../GUI/");
    else
    {
        $_SESSION["alerta"]="Error en la actualización, Contacte a un Ser superior de IT osea un Dios";
        header("Location: ../../GUI/ActualizarCurso.php?id=".$curso->getId());
    }





    