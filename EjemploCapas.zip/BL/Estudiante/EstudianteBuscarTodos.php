<?php
    session_start();
    unset($_SESSION["idUsuario"]);
    //$_SESSION["idUsuario"]=3;

    include '../DAL/Conexion.php';
    include "../Entidades/Estudiantes.php";
    include "../DAL/EstudianteDAL.php";
    include "../Entidades/Cursos.php";
    include "../DAL/CursoDAL.php";


    $estudianteDAL=new EstudianteDAL();

    $todos=$estudianteDAL->BuscarTodos();

    $cursoDAL=new CursoDAL();

    $todosCursos=$cursoDAL->BuscarTodos();

    