<?php

    include '../../DAL/Conexion.php';
    include "../../Entidades/Estudiantes.php";
    include "../../DAL/EstudianteDAL.php";
    
    $estudiante=new Estudiantes();
    $estudianteDAL=new EstudianteDAL();
    
    $estudiante->setNombre($_POST['nombre']);
    $estudiante->setCorreo($_POST['correo']);
    $estudiante->setIdCurso($_POST['idcurso']);

    if($estudianteDAL->Nuevo($estudiante))
        header("Location: ../../GUI/");
    else
        header("Location: ../../GUI/NuevoEstudiante.php");