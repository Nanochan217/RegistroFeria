<?php

    include '../../DAL/Conexion.php';
    include "../../Entidades/Estudiantes.php";
    include "../../DAL/EstudianteDAL.php";
    
    $estudiante=new Estudiantes();
    $estudianteDAL=new EstudianteDAL();
    
    $estudiante->setId($_POST['id']);
    $estudiante->setCorreo($_POST['correo']);

    if($estudianteDAL->ActualizarCorreo($estudiante))
        header("Location: ../../GUI/");
    else
        header("Location: ../../GUI/ActualizarEstudiante.php");


    