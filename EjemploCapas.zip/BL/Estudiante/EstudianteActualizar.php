<?php

    include '../DAL/Conexion.php';
    include "../Entidades/Estudiantes.php";
    include "../DAL/EstudianteDAL.php";
    
    $estudiante=new Estudiantes();
    $estudianteDAL=new EstudianteDAL();

    if(isset($_REQUEST['id']))
    {
        $id=$_REQUEST['id'];
        $estudiante=$estudianteDAL->BuscarID($id);
    }
    else
        header("Location: ./");






    