<?php

    include '../DAL/Conexion.php';
include "../Entidades/Estudiantes.php";
    include "../DAL/EstudianteDAL.php";
    
    $estudiante=new Estudiantes();
    $estudianteDAL=new EstudianteDAL();
    

    