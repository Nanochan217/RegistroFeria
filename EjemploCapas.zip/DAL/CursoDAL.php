<?php

class CursoDAL
{
    function  BuscarId($id)
    {
        $curso = new Cursos();
        $conexion= new Conexion();

        $sql = "SELECT *  FROM `CURSO` WHERE `ID` = '$id'";
        $resultado=$conexion->Ejecutar($sql);

        if(mysqli_num_rows($resultado)>0)
        {
            while ($fila = $resultado->fetch_assoc())
            {
                $curso->setId($fila["ID"]);
                $curso->setNombre($fila["NOMBRE"]);
            }
        }
        else
        {
            $curso=null;
        }
        $conexion->Cerrar();
        return $curso;
    }
    function BuscarTodos()
    {
        $todos=array();
        $conexion= new Conexion();

        $sql = "SELECT * FROM `CURSO`";
        $resultado=$conexion->Ejecutar($sql);
        if(mysqli_num_rows($resultado)>0)
        {
            while ($fila = $resultado->fetch_assoc())
            {
                $e = new Cursos();
                $e->setId($fila["ID"]);
                $e->setNombre($fila["NOMBRE"]);
                $todos[]=$e;
            }
        }
        else
        {
            $todos=null;
        }
        $conexion->Cerrar();
        return $todos;
    }

    function Nuevo(Cursos $c)
    {
        $estado=false;
        $conexion= new Conexion();
        $sql = "INSERT INTO `curso`(`NOMBRE`) VALUES ('".$c->getNombre()."')";
        echo $sql;
        if($conexion->Ejecutar($sql))
        {
            $estado=true;
        }
        $conexion->Cerrar();
        return $estado;
    }

    function ActualizarNombre(Cursos $c)
    {
        $est=false;
        $conexion= new Conexion();
        $sql="Update curso Set NOMBRE='".$c->getNombre()."' Where `ID`=".$c->getId();
        if($conexion->Ejecutar($sql))
        {
            $est = true;
        }
        $conexion->Cerrar();
        return $est;
    }
}
