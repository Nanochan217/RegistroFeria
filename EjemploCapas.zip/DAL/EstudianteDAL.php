<?php

class EstudianteDAL
{
    function BuscarID($id)
    {
        $estudiante = new Estudiantes();
        $conexion= new Conexion();

        $sql = "SELECT *  FROM `ESTUDIANTE` WHERE `ID` = '$id'";
        $resultado=$conexion->Ejecutar($sql);

        if(mysqli_num_rows($resultado)>0)
        {
            while ($fila = $resultado->fetch_assoc())
            {
                $estudiante->setId($fila["ID"]);
                $estudiante->setNombre($fila["NOMBRE"]);
                $estudiante->setCorreo($fila["CORREO"]);
                $estudiante->setIdCurso($fila["IDCURSO"]);
            }
        }
        else
        {
           $estudiante=null;
        }
        $conexion->Cerrar();
        return $estudiante;
    }

    function BuscarTodos()
    {
        $todos=array();
        $conexion= new Conexion();

        $sql = "SELECT * FROM `ESTUDIANTE`";
        $resultado=$conexion->Ejecutar($sql);
        if(mysqli_num_rows($resultado)>0)
        {
            while ($fila = $resultado->fetch_assoc())
            {
                $e = new Estudiantes();
                $e->setId($fila["ID"]);
                $e->setNombre($fila["NOMBRE"]);
                $e->setCorreo($fila["CORREO"]);
                $e->setIdCurso($fila["IDCURSO"]);
                $todos[]=$e;
            }
        }
        else
        {
            $todos=null;
        }
        $conexion->Cerrar();
        return $todos;
    }

    function Nuevo(Estudiantes $e)
    {
        $estado=false;
        $conexion= new Conexion();
        $sql = "INSERT INTO `estudiante`(`NOMBRE`, `CORREO`, `IDCURSO`) VALUES ('".$e->getNombre()."','".$e->getCorreo()."',".$e->getIdCurso().")";
        if($conexion->Ejecutar($sql))
        {
            $estado=true;
        }
        $conexion->Cerrar();
        return $estado;
    }

    function ActualizarCorreo(Estudiantes $e)
    {
        $est=false;
        $conexion= new Conexion();
        $sql="Update ESTUDIANTE Set correo='".$e->getCorreo()."' Where `ID`=".$e->getId();
        if($conexion->Ejecutar($sql))
        {
            $est = true;
        }
        $conexion->Cerrar();
        return $est;
    }
}
